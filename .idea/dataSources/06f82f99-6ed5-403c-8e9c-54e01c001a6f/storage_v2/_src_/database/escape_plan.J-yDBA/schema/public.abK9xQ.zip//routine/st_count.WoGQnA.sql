create function st_count(rastertable text, rastercolumn text, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true) returns bigint
  stable
  strict
  language sql
as
$$
SELECT public._ST_count($1, $2, $3, $4, 1)
$$;

comment on function st_count(text, text, integer, boolean) is 'args: rastertable, rastercolumn, nband=1, exclude_nodata_value=true - Returns the number of pixels in a given band of a raster or raster coverage. If no band is specified defaults to band 1. If exclude_nodata_value is set to true, will only count pixels that are not equal to the nodata value.';

alter function st_count(text, text, integer, boolean) owner to postgres;

