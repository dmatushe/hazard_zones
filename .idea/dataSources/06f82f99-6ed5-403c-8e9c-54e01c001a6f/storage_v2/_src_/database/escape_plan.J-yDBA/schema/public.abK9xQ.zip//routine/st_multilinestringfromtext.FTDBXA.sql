create function st_multilinestringfromtext(text, integer) returns geometry
  immutable
  strict
  parallel safe
  language sql
as
$$
SELECT public.ST_MLineFromText($1, $2)
$$;

alter function st_multilinestringfromtext(text, integer) owner to postgres;

