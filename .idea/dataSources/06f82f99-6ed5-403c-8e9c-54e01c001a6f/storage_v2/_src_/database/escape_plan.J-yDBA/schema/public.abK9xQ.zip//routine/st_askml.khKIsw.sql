create function st_askml(version integer, geog geography, maxdecimaldigits integer DEFAULT 15, nprefix text DEFAULT NULL::text) returns text
  immutable
  parallel safe
  language sql
as
$$
SELECT public._ST_AsKML($1, $2, $3, $4)
$$;

comment on function st_askml(integer, geography, integer, text) is 'args: version, geog, maxdecimaldigits=15, nprefix=NULL - Return the geometry as a KML element. Several variants. Default version=2, default maxdecimaldigits=15';

alter function st_askml(integer, geography, integer, text) owner to postgres;

