create function st_rotate(geometry, double precision) returns geometry
  immutable
  strict
  parallel safe
  language sql
as
$$
SELECT public.ST_Affine($1,  cos($2), -sin($2), 0,  sin($2), cos($2), 0,  0, 0, 1,  0, 0, 0)
$$;

comment on function st_rotate(geometry, double precision) is 'args: geomA, rotRadians - Rotate a geometry rotRadians counter-clockwise about an origin.';

alter function st_rotate(geometry, double precision) owner to postgres;

