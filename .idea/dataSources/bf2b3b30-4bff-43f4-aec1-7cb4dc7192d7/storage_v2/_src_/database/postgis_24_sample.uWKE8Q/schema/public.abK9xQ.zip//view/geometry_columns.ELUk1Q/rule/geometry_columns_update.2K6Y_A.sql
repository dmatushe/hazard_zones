CREATE RULE geometry_columns_update AS
    ON UPDATE TO public.geometry_columns DO INSTEAD NOTHING;

