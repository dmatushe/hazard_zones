create function st_stddev4ma(value double precision[], pos integer[], VARIADIC userargs text[] DEFAULT NULL::text[]) returns double precision
  immutable
  parallel safe
  language sql
as
$$
SELECT stddev(unnest) FROM unnest($1)
$$;

alter function st_stddev4ma(double precision[], integer[], text[]) owner to postgres;

